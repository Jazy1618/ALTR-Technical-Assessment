'''
This is the main file for the webserver. and it mostly works as expected, but
only handles GET requests. An attempt was made to create functionality for a
POST method, but when trying it out, the function would go immediately to the
retry_with_backoff() timing, instead of allowing the 3 requests first.

To run the file, open the terminal and run 'py .\index.py'. The webserver should
load on localhost port 8080.

'''


from http.server import BaseHTTPRequestHandler, HTTPServer
from ratelimit import limits
from datetime import datetime
import time, random, requests

hostName = "localhost"
serverPort = 8080

def tprint(msg):
    timestamp=datetime.now().strftime('%M:%S.%f')[:-3]
    print(timestamp, msg)

def retry_with_backoff(retries = 5, backoff_in_seconds = 1):
    def rwb(f):
        def wrapper(*args, **kwargs):
          x = 0
          while True:
            try:
              return f(*args, **kwargs)
            except:
              if x == retries:
                raise

              sleept = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
              tprint(f"sleep: {sleept}")
              time.sleep(sleept)
              x += 1
                
        return wrapper
    return rwb


@retry_with_backoff(retries=5)
@limits(calls=3, period=30)
class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(bytes("<html><head><title>http://localhost:8080</title></head>", "utf-8"))
        self.wfile.write(bytes("<p>Request: %s</p>" % self.path, "utf-8"))
        self.wfile.write(bytes("<body>", "utf-8"))
        self.wfile.write(bytes("<p>Python web server.</p>", "utf-8"))
        self.wfile.write(bytes("</body></html>", "utf-8"))

    #@retry_with_backoff(retries=5)
    #@limits(calls=3, period=30)
    #def do_POST(self, data):
    #  r = requests.post("http://localhost:8080/POST", data=data)
    #  print(r.json)


if __name__ == "__main__":        
    webServer = HTTPServer((hostName, serverPort), MyServer)
    print("Server started http://%s:%s" % (hostName, serverPort))

    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        pass

    webServer.server_close()
    print("Server stopped.")