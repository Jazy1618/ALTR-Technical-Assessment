import unittest, random, time
from datetime import datetime
from unittest.mock import patch

def tprint(msg):
    timestamp=datetime.now().strftime('%M:%S.%f')[:-3]
    print(timestamp, msg)

'''
def retry_with_backoff(retries = 5, backoff_in_seconds = 1):
    def rwb(f):
        def wrapper(*args, **kwargs):
            x = 0
            while True:
                try:
                    return f(*args, **kwargs)
                except:
                    if x == retries:
                    raise

                    sleep = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
                    tprint(f"sleep: {sleep}")
                    time.sleep(sleep)
                    x += 1
                
        return wrapper
    return rwb
'''

def f() -> int:
  global i
  i = i + 1
  print("  i     :", i);
  if i < 6 or i % 2 != 0:
    raise Exception("Invalid number.")
  return i

def retry_with_backoff(fn, retries = 5, backoff_in_seconds = 1):
    x = 0
    while True:
        try:
            return fn()
        except:
            if x == retries:
                raise

        sleep = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
        time.sleep(sleep)
        x += 1

i = 0

class TestRetryWithBackOff(unittest.TestCase):
    def test_rwb(self):
        with patch('time.sleep') as patched_time_sleep:
            retry_with_backoff(f)
            #time.sleep(7)
            patched_time_sleep.assert_called_once()
        # Should be instant
        #time.sleep(10)
        # the mock should only be called once
        #patched_time_sleep.assert_called_once()



if __name__ == '__main__':
    unittest.main()