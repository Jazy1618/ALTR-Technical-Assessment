import unittest
import requests
#from index import MyServer
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer

hostName = "localhost"
serverPort = 8080

class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(bytes("<html><head><title>http://localhost:8080</title></head>", "utf-8"))
        self.wfile.write(bytes("<p>Request: %s</p>" % self.path, "utf-8"))
        self.wfile.write(bytes("<body>", "utf-8"))
        self.wfile.write(bytes("<p>Python web server.</p>", "utf-8"))
        self.wfile.write(bytes("</body></html>", "utf-8"))

class TestServer(unittest.TestCase):
    def test_get_send_response(self):
        ws = HTTPServer((hostName, serverPort), MyServer)
        r = requests.get(f"http://localhost:8080").status_code
        print(r)
        self.assertEquals(r, 200)
        ws.server_close()
        print("Server closed.")

if __name__ == '__main__':
    unittest.main()