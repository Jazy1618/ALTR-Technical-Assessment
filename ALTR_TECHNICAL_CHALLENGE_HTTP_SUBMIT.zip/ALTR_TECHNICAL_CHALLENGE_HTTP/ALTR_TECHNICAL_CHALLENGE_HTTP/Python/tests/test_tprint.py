import unittest
from datetime import datetime
from unittest.mock import patch

def tprint(msg):
    timestamp=datetime.now().strftime('%M:%S.%f')[:-3]
    print(timestamp, msg)

class TestTPrint(unittest.TestCase):
    # Check that print() was called; implicit assumption that all functions being used are working
    def test_tprint(self):
        with patch('builtins.print') as mock_print:
            tprint("Test message")
            mock_print.assert_called()


if __name__ == '__main__':
    unittest.main()