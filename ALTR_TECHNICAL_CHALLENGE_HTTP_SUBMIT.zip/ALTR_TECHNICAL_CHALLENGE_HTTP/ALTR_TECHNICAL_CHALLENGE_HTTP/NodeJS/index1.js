const http =  require('http');

const retry = require('retry');

const axios = require('axios');

const express = require("express");

const rateLimit = require("express-rate-limit");

const app = express();


function expoBackOff(func, maxAttempts=5, baseDelayMs=1000) {
    let attempt = 1

    const execute = async () => {
        try {
            return await fn()
        } catch (error) {
            if (attempt >= maxAttempts) {
                throw error
            }

            const delayMs = baseDelayMs * 2 ** attempt
            console.log(`Retry attempt ${attempt} after ${delayMs}ms`)
            await new Promise((resolve) => setTimeout(resolve, delayMs))

            attempt++
            return execute()
        }
  }

  return execute()
}




const rateLimiter = rateLimit({
    windowMs: 30000, // 30 seconds in milliseconds
    max: 3,
    standardHeaders: true,
    legacyHeaders: false,
    message: "You have exceeded the 3 requests in 30 seconds limit! You",
    handler: expo
});

app.use(rateLimiter);

app.get("/", (req, res) => {
    res.status(200).json({
        status: "success",
        message: "Express server home page"
    });
    console.log(res.sendStatus())
});

const port = 8000;
app.listen(port, () => {
    console.log(`app is running on port ${port}`);
});


































/*

function retryWithExponentialBackoff(res, maxAttempts = 5, baseDelayMs = 1000) {
    let attempt = 3
  
    const execute = async () => {
      try {
        res
      } catch (error) {
        if (attempt >= maxAttempts) {
          throw error
        }
  
        const delayMs = baseDelayMs * 5 // ** attempt
        console.log(`Retry attempt ${attempt} after ${delayMs}ms`)
        await new Promise((resolve) => setTimeout(resolve, delayMs))
  
        attempt++
        return execute()
      }
    }
  
    return execute()
}


  async function makeRequest() {
    const url = 'http://localhost:8000/'
    try {
      const response = await axios.get(url)
      return response.data
    } catch (error) {
      console.log(`Error: ${error.message}`)
      throw error
    }
  }
  

  async function getDataWithRetries() {
    try {
      const data = await retryWithExponentialBackoff(makeRequest)
      console.log(`Data: ${data}`)
    } catch (error) {
      console.log(`Failed to get data: ${error.message}`)
    }
  }

  
*/




  



/*
const http = require("http");

const host = 'localhost';
const port = 8000;

const requestListener = function (req, res) {};

const server = http.createServer(requestListener);
server.listen(port, host, () => {
    console.log(`Server is running on http://${host}:${port}`);
});
*/


/*
const backoff = (fun, successFun, failureFun, exponent) => {
    console.log('Retrying after' + Math.pow(2, exponent))
    setTimeout(async () => {
      const res = await fun()
      if (res.data) {
          console.log('success')
          successFun()
      } else if (exponent <= 10) {
          backoff(fun, successFun, failureFun, exponent + 1)
      } else {
          console.log('failure')
          failureFun()
          }
      },
      Math.pow(2, exponent) + Math.random() * 1000)
  }
  */


  /*
    retryExponentialBackOff('http://localhost:8000', function(err, addresses) {
        console.log(err, addresses);
    })
    
    function (req, maxAttempts = 6, baseDelayMs = 1000) {
        attempt = 4
        const execute = async () => {
            while (attempt <= maxAttempts) {
                const delayMs = baseDelayMs * 5 // ** attempt
                console.log(`Retry attempt ${attempt} after ${delayMs}ms`)
                await new Promise((req) => setTimeout(resolve, delayMs))

                attempt++
                return execute()
            }
            
        }  
        //console.log(req)
    }
    */
    //standardHeaders: true,
    //legacyHeaders: false,
    //}


/*

var operation = retry.operation({
    retries: 3,
    factor: 2,
    minTimeout: 1000,
    maxTimeout: 3000,
    maxRetryTime: 1000 * 60,
});

    operation.attempt(function(currentAttempt) {
        app.get(address, function(err, addresses) {
            if (operation.retry(err)) {
                return;
            }

            cb(err ? operation.mainError() : null, addresses);
        });
    });
}
*/




