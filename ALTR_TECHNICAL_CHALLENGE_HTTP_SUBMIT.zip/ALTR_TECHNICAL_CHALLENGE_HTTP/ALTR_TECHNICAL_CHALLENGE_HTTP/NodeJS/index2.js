/*
Scenario: HTTP Webserver Implementation       
When: An HTTP request is received  
Then: The webserver determines if the requesting client has exceeded the
request limit of 3 requests per IP address per 30 seconds. If the limit
has been exceeded, the webserver is expected to reject the request. If
the limit is not exceeded, the webserver is expected to successfully
service the request.
*/

const express = require("express");

const rateLimit = require("express-rate-limit");

const app = express();

const rateLimiter = rateLimit({
    windowMs: 30000, // 30 seconds in milliseconds
    max: 3,
    message: 'You have exceeded the 3 requests in 30 seconds limit!',
    standardHeaders: true,
    legacyHeaders: false,

});


app.use(rateLimiter);

app.get("/", (req, res) => {
    res.status(200).json({
        status: "success",
        message: "Express server home page"
    });
});


const port = 8000;
app.listen(port, () => {
    console.log(`app is running on port ${port}`);
});



function retryWithExponentialBackoff(func, maxAttempts = 5, baseDelayMs = 1000) {
    let attempt = 3
  
    const execute = async () => {
      try {
        return await func()
      } catch (error) {
        if (attempt >= maxAttempts) {
          throw error
        }
  
        const delayMs = baseDelayMs * 5 // ** attempt
        console.log(`Retry attempt ${attempt} after ${delayMs}ms`)
        await new Promise((resolve) => setTimeout(resolve, delayMs))
  
        attempt++
        return execute()
      }
    }
  
    return execute()
}

/*
const rateLimiter = rateLimit({
    windowMs: 30000, // 30 seconds in milliseconds
    max: 3,
    message: 'You have exceeded the 3 requests in 30 seconds limit!',    
    handler: operation.attempt(async (currentAttempt) => {
        console.log('sending request: ', currentAttempt, 'attempt');
        try {
            await app.get("/")
        } catch (e) {
            if (operation.retry(e)) { return; }
        }
    })
    
});
*/