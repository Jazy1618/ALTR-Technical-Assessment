The NodeJS folder holds the files and notes from my attempt to complete this assessment in NodeJS and
Express. Despite my efforts, I was not able to do it entirely. I realized that I knew how to implement
rate limiting, as well as exponential backoff, but I could not manage to combine them in such a way
that the exponential backoff only kicked in after reaching the rate limit. After spending a great
deal of time on it, I decided to try it instead in Python, which seemed more familiar to me but also
was not without flaws. This folder and its contents can be ignored for testing, there are no unit tests,
but I hope it helps to show my efforts on this assignment and possibly how much I could learn with you.