'''
In this test file, I wanted to test the retry_with_backoff function, specifically
to see if it was calling the time.sleep() function is being called, and if the value
of sleept is correct. The tests are incomplete.

If you are using PyCharm, you can run these tests by right clicking on the 'unit_tests' folder and selecting
"Run 'Python tests in unit_tests'". Alternatively, you can use the shortcut of Ctrl+Shift+F10.

'''

import unittest, random, time, requests
from datetime import datetime
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer

def tprint(msg):
    timestamp=datetime.now().strftime('%M:%S.%f')[:-3]
    print(timestamp, msg)


def retry_with_backoff(retries = 5, backoff_in_seconds = 1):
    def rwb(f):
        def wrapper(*args, **kwargs):
            x = 0
            while True:
                try:
                    return f(*args, **kwargs)
                except:
                    if x == retries:
                        raise

                    sleept = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
                    tprint(f"sleep: {sleept}")
                    time.sleep(sleept)
                    x += 1
                
        return wrapper
    return rwb


class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(bytes("<html><head><title>http://localhost:8080</title></head>", "utf-8"))
        self.wfile.write(bytes("<p>Request: %s</p>" % self.path, "utf-8"))
        self.wfile.write(bytes("<body>", "utf-8"))
        self.wfile.write(bytes("<p>Python web server.</p>", "utf-8"))
        self.wfile.write(bytes("</body></html>", "utf-8"))


'''
def retry_with_backoff(fn, retries = 5, backoff_in_seconds = 1):
    x = 0
    while True:
        try:
            return fn()
        except:
            if x == retries:
                raise

        sleept = (backoff_in_seconds * 2 ** x + random.uniform(0, 1))
        time.sleep(sleept)
        x += 1

i = 0
'''


class TestRetryWithBackOff(unittest.TestCase):
    def test_rwb(self):
        with patch('time.sleep') as patched_time_sleep:
            #ws = M
            resp = requests.get('localhost:8080/').status_code
            print(resp)
            retry_with_backoff(MyServer.do_GET(self))
            #time.sleep(7)
            patched_time_sleep.assert_called()



if __name__ == '__main__':
    unittest.main()