'''
In this test file, I wanted to test if my Python server class is being properly
set up. I wanted tests for the do_GET method and for the reponse object from
the server to see if the status code is 200. The tests are incomplete.

If you are using PyCharm, you can run these tests by right clicking on the 'unit_tests' folder and selecting
"Run 'Python tests in unit_tests'". Alternatively, you can use the shortcut of Ctrl+Shift+F10.

'''


import unittest
import requests
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer

hostName = "localhost"
serverPort = 8080

class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(bytes("<html><head><title>http://localhost:8080</title></head>", "utf-8"))
        self.wfile.write(bytes("<p>Request: %s</p>" % self.path, "utf-8"))
        self.wfile.write(bytes("<body>", "utf-8"))
        self.wfile.write(bytes("<p>Python web server.</p>", "utf-8"))
        self.wfile.write(bytes("</body></html>", "utf-8"))

class TestServer(unittest.TestCase):
    def test_do_GET(self):
        ws = HTTPServer((hostName, serverPort), MyServer)
        #r = requests.get(f"http://localhost:8080").status_code
        #print(r)
        #self.assertEquals(r, 200)
        r = ws.get_request()
        print(r)
        ws.server_close()

if __name__ == '__main__':
    unittest.main()