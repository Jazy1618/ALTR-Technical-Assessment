const express = require("express");
const rateLimit = require("express-rate-limit");


const app = express();


const rateLimiter = rateLimit({
    windowMs: 30000, // 30 seconds in milliseconds
    max: 3,
    standardHeaders: true,
    legacyHeaders: false,
    message: "You have exceeded the 3 requests in 30 seconds limit!"
});


app.use(rateLimiter);
app.use(express.json());

app.get("/", (req, res) => {
    res.status(200).json({
        status: "success",
        message: "A GET request to the server"
    });
    console.log(req.body);
});

app.post("/", (req, res) => {
    res.status(201).json({
        status: "success",
        message: "A POST request to the server"
    });
    console.log(req.body);
});

app.put("/", (req, res) => {
    res.status(200).json({
        status: "success",
        message: "A PUT request to the server"
    });
    console.log(req.body);
});

const port = 8000;
app.listen(port, () => {
    console.log(`app is running on port ${port}`);
});

module.exports = app;