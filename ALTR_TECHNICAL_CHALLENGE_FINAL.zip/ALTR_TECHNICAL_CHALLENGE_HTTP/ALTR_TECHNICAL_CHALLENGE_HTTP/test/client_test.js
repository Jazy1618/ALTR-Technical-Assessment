const chai = require('chai');
const http =  require('http');
const sinon = require('sinon');
const expect = require('chai').expect;
const sinonChai = require('sinon-chai');
const assert = require('assert');
const clientGET = require('../client/clientGET');
const clientPUT = require('../client/clientPUT');
const clientPOST = require('../client/clientPOST');
//import { expoBackOff } from '../client/clientGET';

chai.use(sinonChai);


// I placed the function in here, since I ws having trouble trying to test the function from a separate file
async function expoBackOff(baseDelay=1000) {
    for (let i = 1; i < 6; i++){
        const delayMs = baseDelay * 2 ** i;
        console.log(`Retry attempt ${i} after ${delayMs}ms`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
};


describe('Client has made a GET request', function () {
    beforeEach( async () => {
        sinon.spy(console, 'log');
        await new Promise(resolve => setTimeout(resolve, 1000));
        console.log("------------GET----------");
    });
    afterEach(async function () {
        sinon.restore();
    });
    
    // tests that expoBackOff is calling console.log()
    it ('should call console.log()', function () {
        expoBackOff();
        expect(console.log).to.be.called;
    });

    // test clientGET.js
    it('should return status code 200 for GET', function () {
        http.request(clientGET.optionsGET, function(res) {
            assert.equal(res.statusCode, 200);
            /*
            // attempted to have a version that would assert based on the status code
            if (res.statusCode == 200) {
                assert.equal(res.statusCode, 200);
            } else if (res.statusCode == 429) {
                
                let spy = sinon.spy(expoBackOff);
                assert(spy.called());
                //assert.
            }
            */
        });
        //done();
    });

    // tests clientPOST.js
    it('should return status code 201 for POST', function () {
        http.request(clientPOST.optionsPOST, function(res) {
            assert.equal(res.statusCode, 201);
        });
        //done();
    });

    // tests clientPUT.js
    it('should return status code 200 for PUT', function () {
        http.request(clientPUT.optionsPUT, function(res) {
            assert.equal(res.statusCode, 200);
        });
        //done();
    });
    
});









    /*
    // test clientPOST.js
    it('should return status code 201 for POST', function (done) {
        http.request(clientPOST.optionsPOST, function(res) {
            assert.equal(res.statusCode, 201);
        });
        done();
    });
    */







/*


//expoBackOff(res)
        //let spy = sinon.spy(console, 'log');
        //assert(spy.called());


    it('should return status code 200 for GET', function (done) {
        chai.request(clientGET)
            .get('/')
            .end((err, res) => {
                res.should.have.status(200);
            });
        /*
        http.get("http://localhost:8000", function(res) {
            assert.equal(res.statusCode, 200);
        });
        done();
    });
    */