/*

const http =  require('http');
const assert = require('assert');
const require = require('supertest')
//const request = require('request');
const clientPUT = require('../client/clientPUT');

describe('Client has made a PUT request', function () {
    beforeEach( async () => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        console.log("-----------PUT-----------");
    });
    
    it('should return status code 200 for PUT', function (done) {
        http.request(clientPUT.optionsPUT, function(res) {
            assert.equal(res.statusCode, 200);
        });
        done();
    });
/*
    it('should get')
    done();

});

*/