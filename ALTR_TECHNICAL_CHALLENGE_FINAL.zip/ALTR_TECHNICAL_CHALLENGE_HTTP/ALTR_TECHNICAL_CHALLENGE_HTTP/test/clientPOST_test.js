/*

const http =  require('http');
const assert = require('assert');
//const request = require('request');
const clientPOST = require('../client/clientPOST');

describe('Client has made a POST request', function () {
    beforeEach( async () => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        console.log("-----------POST-----------");
    });

    it('should return status code 201 for POST', function (done) {
        http.request(clientPOST.optionsPOST, function(res) {
            assert.equal(res.statusCode, 201);
        });
        done();
    });
});

*/