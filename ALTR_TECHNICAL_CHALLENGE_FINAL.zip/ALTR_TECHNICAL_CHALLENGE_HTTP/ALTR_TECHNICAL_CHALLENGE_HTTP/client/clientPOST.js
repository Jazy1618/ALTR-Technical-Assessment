const http =  require('http');


const dataPOST = {
    name: 'Apple',
    count: 5,
    description: 'POST 5 apples'
};

const optionsPOST = {
    host: 'localhost',
    port: '8000',
    method: 'POST',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json; character=UTF-8'
    }
};

async function expoBackOff(baseDelay=1000) {
    for (let i = 1; i < 6; i++){
        const delayMs = baseDelay * 2 ** i;
        console.log(`Retry attempt ${i} after ${delayMs}ms`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
};

let requestPOST = http.request(optionsPOST, (res) => {
    if (res.statusCode !== 201) {
        console.error(`Server did not send Created. Code: ${res.statusCode}`);
        if (res.statusCode == 429) {
            expoBackOff();
        }
        res.resume();
        return;
    }

    let data = '';

    res.on('data', (chunk) => {
        data += chunk;
    });
  
    res.on('close', () => {
        console.log('POST\'d apples');
        console.log(JSON.parse(data));
    });

    //console.log('POST successful. Status code is', res.statusCode);
});

requestPOST.write(JSON.stringify(dataPOST));
requestPOST.end()


requestPOST.on('error', (err) => {
    console.error(`Hey, we encountered an error trying to make a POST request: ${err.message}`);
});








// RANDOM CODE CHUNKS
/*
        if (res.statusCode == 429) {
            for (let i = 1; i < 6; i++){
                const delayMs = baseDelay * 2 ** i;
                console.log(`Retry attempt ${i} after ${delayMs}ms`);
                await new Promise((resolve) => setTimeout(resolve, delayMs));
            }
        }
        */