const http =  require('http');
const request = require('supertest');


const dataGET = {
    fruit1: 'Apple',
    fruit2: 'Banana',
    total: 7
};

const optionsGET = {
    host: 'localhost',
    port: '8000',
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json; character=UTF-8'
    }
};

async function expoBackOff(baseDelay=1000) {
    for (let i = 1; i < 6; i++){
        const delayMs = baseDelay * 2 ** i;
        console.log(`Retry attempt ${i} after ${delayMs}ms`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
};

let requestGET = http.request(optionsGET, (res) => {
    if (res.statusCode !== 200) {
        console.error(`Server status is not OK. Code: ${res.statusCode}`);
        if (res.statusCode == 429) {
            expoBackOff();
        }
        res.resume();
        return;
    }

    let data = '';

    res.on('data', (chunk) => {
        data += chunk;
    });

    res.on('close', () => {
        console.log('GET\'d all fruit');
        console.log(JSON.parse(data));
    });
    
    //console.log('GET successful. Status code is', res.statusCode);
});

requestGET.write(JSON.stringify(dataGET));
requestGET.end();


requestGET.on('error', (err) => {
    console.error(`Hey, we encountered an error trying to make a GET request: ${err.message}`);
});







// RANDOM CODE CHUNKS

/*
        if (res.statusCode == 429) {
            for (let i = 1; i < 6; i++){
                const delayMs = baseDelay * 2 ** i;
                console.log(`Retry attempt ${i} after ${delayMs}ms`);
                await new Promise((resolve) => setTimeout(resolve, delayMs));
            }
        }
        */









/*

function error429() {
    throw {
      name: '429',
      message: 'Too many requests'
    };
};


let requestGET = http.get('http://localhost:8000', async (res, attempts=3, baseDelay=1000) => {
    //let currAttempt = 1
    if (res.statusCode == 429) {
        let currAttempt = 1;
        console.error(`Error code is 429 - Too many requests`);
       
        try {
            //http.get('http://localhost:8000');
            //await new Promise((resolve) => setTimeout(resolve, delayMs));
            await requestGET;
            console.log('Ran request again');
            throw error429();
        } catch (err) {
            if (err.name == '429' && currAttempt >= attempts) {
                console.log('Server is overloading - no more attempts!');
                return;
            }
            const delayMs = baseDelay * 2 ** currAttempt;
            console.log(`Retry attempt ${currAttempt} after ${delayMs}ms`);
            await new Promise((resolve) => setTimeout(resolve, delayMs));
            currAttempt++;
            //await requestGET;      
        }
        //await request;

        //res.resume();
        return;
    }
    console.log('Status code is', res.statusCode);
});
*/

//let request = http.get('http://localhost:8000', retryWithExponentialBackoff(http.get('http://localhost:8000')));

/*
http.get() version
//let currAttempt = 1

let requestGET = http.get('http://localhost:8000', async (res, attempts=3, baseDelay=1000) => {
    //let currAttempt = 1
    if (res.statusCode == 429) {
        let currAttempt = 1;
        console.error(`Error code is 429 - Too many requests`);
       
        try {
            //http.get('http://localhost:8000');
            throw err; // error429();
        } catch (err) {
            if (currAttempt >= attempts) {
                console.log('Server is overloading - no more attempts!');
                return;
            }
            const delayMs = baseDelay * 2 ** currAttempt;
            console.log(`Retry attempt ${currAttempt} after ${delayMs}ms`);
            await new Promise((resolve) => setTimeout(resolve, delayMs));
            currAttempt++;
            //await requestGET;      
        }

        //res.resume();
        return;
    }
    console.log('Status code is', res.statusCode);
});
*/