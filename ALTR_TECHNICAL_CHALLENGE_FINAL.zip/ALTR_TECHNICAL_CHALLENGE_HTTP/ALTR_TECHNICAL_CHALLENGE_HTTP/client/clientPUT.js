const http =  require('http');


const dataPUT = {
    name: 'Banana',
    count: 2,
    description: 'PUT 2 bananas'
};

const optionsPUT = {
    host: 'localhost',
    port: '8000',
    method: 'PUT',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json; character=UTF-8'
    }
};

async function expoBackOff(baseDelay=1000) {
    for (let i = 1; i < 6; i++){
        const delayMs = baseDelay * 2 ** i;
        console.log(`Retry attempt ${i} after ${delayMs}ms`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
};

let requestPUT = http.request(optionsPUT, (res) => {
    if (res.statusCode !== 200) {
        console.error(`Server status is not OK. Code: ${res.statusCode}`);
        if (res.statusCode == 429) {
            expoBackOff();
        }
        res.resume();
        return;
    }

    let data = '';

    res.on('data', (chunk) => {
        data += chunk;
    });
  
    res.on('close', () => {
        console.log('PUT\'d bananas');
        console.log(JSON.parse(data));
    });

    //console.log('PUT successful. Status code is', res.statusCode);
});

requestPUT.write(JSON.stringify(dataPUT));
requestPUT.end()


requestPUT.on('error', (err) => {
    console.error(`Hey, we encountered an error trying to make a PUT request: ${err.message}`);
});







// RANDOM CODE CHUNKS
/*
        if (res.statusCode == 429) {
            for (let i = 1; i < 6; i++){
                const delayMs = baseDelay * 2 ** i;
                console.log(`Retry attempt ${i} after ${delayMs}ms`);
                await new Promise((resolve) => setTimeout(resolve, delayMs));
            }
        }
        */